
from flask import Flask, render_template, request, redirect, session 
import random 
app = Flask(__name__)
app.secret_key = "Greater Number"

@app.route('/')
def index():
    print("This is Working")
    if "number" not in session: 
        session['number'] =random.randint(1,100)
    if 'guess' not in session:
        session['guess'] = -1
    print(session['number'])
    return render_template('guess.html')


@app.route('/guess', methods = ['POST'])
def guess():
    session['guess'] = int(request.form['number'])
    message = ''
    if session['guess'] == session['number']:
        Message = 'WINNER!'
    if session['guess'] > session['number']: 
        Message="TOO HIGH!"
    if session['guess'] < session['number']:
        Message = 'TOO LOW!'
    if 'count' not in session:
        session['count'] = 0
    session['count'] += 1 
    return render_template('great_number.html',message=Message)


@app.route('/clear')
def clear():
    session.pop('count')
    session.pop('number')
    return redirect('/')
    

if __name__== "__main__":
    app.run(debug=True)