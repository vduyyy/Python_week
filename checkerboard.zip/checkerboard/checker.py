from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('checker.html', times =8)


@app.route('/<x>')
def second(x):
    times = int(x)
    return render_template('checker.html', times = times)


if __name__ == "__main__":
    app.run(debug=True)