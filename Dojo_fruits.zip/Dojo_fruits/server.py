#!/user/bin/env python3 
from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    count = int(request.form['strawberry']) + int(request.form["raspberry"]) + int(request.form["apple"])
    print(request.form)
    return render_template("checkout.html", N = request.form["first_name"], LN = request.form["last_name"], ID = request.form["student_id"],SB = request.form["strawberry"], RB = request.form["raspberry"], A = request.form["apple"], count = count)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")



if __name__=="__main__":   
    app.run(debug=True)    