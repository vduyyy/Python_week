from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('survey.html')

@app.route('/result', methods=['POST'])
def display_user():
    print("IS this working!")
    print(request.form)
    return render_template('end_survey.html', N = request.form["Name"],DL = request.form["Dojo Location"], L= request.form["Language"], C = request.form["Comment"])

if __name__ == "__main__":
    app.run(debug =True)