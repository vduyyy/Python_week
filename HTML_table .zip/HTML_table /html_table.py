from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    users= (
       {'name' : 'Michael', 'age' : 35},
       {'name' : 'John', 'age' : 30 },
       {'name' : 'Mark', 'age' : 25},
       {'name' : 'KB', 'age' : 27}
    )
    for x in users:
      print(x['name'],x['age'])

    users = (
       {'first_name' : 'Michael ', 'last_name' :'Choi' },
       {'first_name' : 'John ', 'last_name' : 'Supsupin' },
       {'first_name' : 'Mark ', 'last_name' : 'Guillen'},
       {'first_name' : 'KB ', 'last_name' : 'Tonel'}
    )
    for x in users:
      print(x['first_name'],x['last_name'])
     

    return render_template("lists.html", users = users)
    
if __name__=="__main__":
    app.run(debug=True)