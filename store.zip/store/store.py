class Store: 
    def __init__(self, name,list_products):
        self.name = name
        self.list_products = list_products

    def add_product(self, new_product):
        print ("New Product\n")
        self.list_products.append(new_product)
    
    def sell_product(self,id):
        print("remove product")
        self.list_products.remove(id)
    
    def inflation_product(self):
        self.inflation_product 
    
    def set_clearance(self):
        self.set_clearance
    

store = Store("Cat", ["Fish", "Veg", "Noodle"])
store2 = Store("Tom", ["Corn", "Turkey", "Steak"])

print(store.name, store.list_products)
print(store2.name, store2.list_products)


class Product(Store): 
    def __init__(self,name, price,category): 
        self.name = name
        self.price = price 
        self.category = category
    
    def update_price(self,percent_change, is_increased):
        if self.is_increased > self.update_price:
            print("True")
        else: 
            print("False")

    def print_info(self):
        print(self.name) 
        print(self.category)
        print(self.price)

Fish = Product("Tulip", 15, "Seafood")
Fish2 = Product("Catfish", 20, "Seafood")

print(Fish.name,Fish.price,Fish.category)
print(Fish2.name, Fish2.price,Fish2.category)