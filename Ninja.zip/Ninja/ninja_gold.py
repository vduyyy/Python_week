from flask import Flask, render_template, request, redirect, session 
import random
app = Flask(__name__)
app.secret_key = "This is Another secret"



def track( num, action, location):
    if location == "Farm":
        session['activity'].append('Earned %d from  the %s' % (num, location))
    if location == "Cave":
        session['activity'].append('Earned %d from  the %s' % (num, location))
    if location == "House":
        session['activity'].append('Earned %d from  the %s' % (num, location))
    if location == "Casino":
        if action == ' earned': 
            earned = 'Earned %d from the casino! %s' % (num, location)
            session['activity'].append([earned])
        elif action == 'lost': 
            lost = 'You enter casino and lost %d gold %s' %(num, location)
            session['activity'].append([lost])


@app.route('/')
def index():
    if "total" not in session: 
        session['total'] = 0 
    if 'activity' not in session:
        session['activity'] = []
    
    print('This is Working!')
    return render_template('ninja.html', total = session['total'], activity = session['activity'])

@app.route('/gold', methods = ['POST'])
def gold():
    if request.form['building'] == 'Farm':
        farm_num = random.randint(10,20)
        session['total'] +=farm_num
        track(farm_num, 'earned', 'Farm')
    if request.form['building'] == 'Cave':
        cave_num = random.randint(5,10)
        session['total'] +=cave_num
        track(cave_num, 'earned', 'Cave')
    if request.form['building'] == 'House':
        house_num = random.randint(2,10)
        track(house_num, 'earned', 'House')
        session['total'] += house_num
    if request.form['building'] == 'Casino':
        casino_num = random.randint(-10,50)
        if casino_num > 0:
            track(casino_num, 'earned', 'Casino')
            session['total'] += casino_num
        if casino_num < 0:
            track(casino_num, 'lost', 'Casino')
            session['total'] -= casino_num
    return redirect('/')

@app.route('/clear')
def clear():
    session.pop('total')
    session['activity'] = []
    return redirect('/')

if __name__=="__main__":
    app.run(debug=True)